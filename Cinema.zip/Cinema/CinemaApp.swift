//
//  CinemaApp.swift
//  Cinema
//
//  Created by Student on 20.01.2022.
//

import SwiftUI

@main
struct CinemaApp: App {
    var body: some Scene {
        WindowGroup {
            SignIn()
        }
    }
}
